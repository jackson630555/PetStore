package simulations
import io.gatling.http.Predef._
import io.gatling.core.Predef._

class PetStore extends Simulation{
  val httpconfig = http.baseUrl("https://petstore.swagger.io/")
  val sessionheaders = Map("cookie" ->"cookiehub=eyJhbnN3ZXJlZCI6dHJ1ZSwicmV2aXNpb24iOjEsImRudCI6ZmFsc2UsImFsbG93U2FsZSI6dHJ1ZSwiaW1wbGljdCI6ZmFsc2UsInJlZ2lvbiI6IkM0IiwidG9rZW4iOiIwbGJPbHBRcXZUTkRvVEJqYm5BMmZOV2N3bEdOeG9rVVU4TDBpV2RmS3BpQk00NW41UTdpa1lZSmNLVGxyZ0FUIiwidGltZXN0YW1wIjoiMjAyNS0wMS0yM1QwNDowMDo1OS40ODZaIiwiYWxsQWxsb3dlZCI6dHJ1ZSwiY2F0ZWdvcmllcyI6W10sInZlbmRvcnMiOltdLCJzZXJ2aWNlcyI6W10sImltcGxpY2l0IjpmYWxzZX0=; _ga=GA1.1.229498536.1737604855; _ga_R8SY7470GY=GS1.1.1737709402.2.0.1737709402.0.0.0; userId=2425791749017707633; cebs=1; _ce.clock_data=65%2C%2C1%2C0fe6feb54289f4c67027ec06cc2131f8%2CChrome%2C; cebsp_=1; _ce.s=v~b05c88b74ed0e31f6113b32259387677c915b906~lcw~1749017710614~vir~new~lva~1749017709644~vpv~1~v11.cs~243208~v11.s~44f94d40-410b-11f0-90a7-372d0180366a~v11.vs~b05c88b74ed0e31f6113b32259387677c915b906~v11ls~44f94d40-410b-11f0-90a7-372d0180366a~lcw~1749017710618; _ga_F11FV1HQ2E=GS2.1.s1749017708$o1$g1$t1749018026$j60$l0$h0","accept" ->"application/json")

  val scn = scenario("PetStore API calls")
    .exec(
      http("PetStore details based on ID")
        .get("v2/pet/12")
        .headers(sessionheaders)
    )
  setUp(scn.inject(atOnceUsers(1))).protocols(httpconfig)

}
